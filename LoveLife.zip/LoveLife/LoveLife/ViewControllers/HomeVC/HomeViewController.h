//
//  HomeViewController.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/29.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import "RootViewController.h"

@interface HomeViewController : RootViewController

@end
