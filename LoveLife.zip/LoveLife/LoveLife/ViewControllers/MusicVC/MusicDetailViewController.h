//
//  MusicDetailViewController.h
//  LoveLife
//
//  Created by qiaqnfeng on 16/1/4.
//  Copyright © 2016年 CCW. All rights reserved.
//

#import "RootViewController.h"

@interface MusicDetailViewController : RootViewController

//种类
@property (nonatomic,copy) NSString *typeString;
//url
@property (nonatomic,copy) NSString *urlString;

@end
