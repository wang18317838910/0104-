//
//  PlayViewController.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/31.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface PlayViewController : MPMoviePlayerViewController

@end
