//
//  FoodDetailViewController.h
//  LoveLife
//
//  Created by qiaqnfeng on 16/1/2.
//  Copyright © 2016年 CCW. All rights reserved.
//

#import "RootViewController.h"

@interface FoodDetailViewController : RootViewController

@property (nonatomic,strong) NSString *dishID;
@property (nonatomic,strong) NSString *foodName;

@end
