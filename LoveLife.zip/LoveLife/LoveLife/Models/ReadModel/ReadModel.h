//
//  ReadModel.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/30.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ReadModel : NSObject

@property (nonatomic,copy) NSString *author;
@property (nonatomic,copy) NSString *createtime;
@property (nonatomic,copy) NSString *dataID;
@property (nonatomic,copy) NSString *pic;
@property (nonatomic,copy) NSString *title;

@end
