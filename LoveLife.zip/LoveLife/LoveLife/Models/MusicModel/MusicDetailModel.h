//
//  MusicDetail.h
//  LoveLife
//
//  Created by qiaqnfeng on 16/1/4.
//  Copyright © 2016年 CCW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicDetailModel : NSObject

@property (nonatomic,copy) NSString *artist;
@property (nonatomic,copy) NSString *coverURL;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *url;

@end
