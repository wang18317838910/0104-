//
//  MusicDetail.m
//  LoveLife
//
//  Created by qiaqnfeng on 16/1/4.
//  Copyright © 2016年 CCW. All rights reserved.
//

#import "MusicDetailModel.h"

@implementation MusicDetailModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
