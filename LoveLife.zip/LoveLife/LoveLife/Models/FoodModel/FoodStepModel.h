//
//  FoodStepModel.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/31.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodStepModel : NSObject

//描述
@property (nonatomic,strong) NSString *dishes_step_descString;
//图片
@property (nonatomic,strong) NSString *dishes_step_imageString;

@end
