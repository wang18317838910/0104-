//
//  FoodModel.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/31.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodModel : NSObject

@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *detail;
@property (nonatomic,strong) NSString *image;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *video;
@property (nonatomic,strong) NSString *dishes_id;


@end
