//
//  FoodStepModel.m
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/31.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import "FoodStepModel.h"

@implementation FoodStepModel

@end
