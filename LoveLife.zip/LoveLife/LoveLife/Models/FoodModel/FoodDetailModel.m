//
//  FoodDetail.m
//  LoveLife
//
//  Created by qiaqnfeng on 16/1/2.
//  Copyright © 2016年 CCW. All rights reserved.
//

#import "FoodDetailModel.h"

@implementation FoodDetailModel

@end
