//
//  FoodTitleCollectionViewCell.h
//  LoveLife
//
//  Created by qiaqnfeng on 15/12/31.
//  Copyright © 2015年 CCW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodTitleCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UILabel *titleLabel;

@end
